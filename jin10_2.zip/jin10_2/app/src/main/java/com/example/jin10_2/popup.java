package com.example.jin10_2;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.widget.EditText;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;

import static androidx.constraintlayout.widget.Constraints.TAG;

public class popup extends AppCompatActivity {
    private String zone;
    private String userID;
    private TextView textView1,textView2,mTextViewResult;

    private static String IP_ADDRESS = "jin10.dothome.co.kr";
    private static String TAG = "phpexample";

    ArrayList<HashMap<String, String>> mArrayList;
    ListView mListViewList;
    private String mJsonString;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_popup);
        Intent intent = getIntent();
        zone = intent.getStringExtra("zone");
        userID = intent.getStringExtra("userID");
        mListViewList = (ListView) findViewById(R.id.listView_main_list);
        textView1 = findViewById(R.id.text_popup1);
        textView2 = findViewById(R.id.text_popup2);
        mTextViewResult = findViewById(R.id.mTextViewResult);


        textView1.setText(userID + "님 반갑습니다");
        textView2.setText(zone + "의 오토바이 목록입니다.");


        String Keyword = zone;

        GetData task = new GetData();
        task.execute("http://" + IP_ADDRESS + "/query.php", Keyword);

        mArrayList = new ArrayList<>();

    }



private class GetData extends AsyncTask<String, Void, String>{

    ProgressDialog progressDialog;
    String errorString = null;

    @Override
    protected void onPreExecute() {
        super.onPreExecute();

        progressDialog = ProgressDialog.show(popup.this,
                "Please Wait", null, true, true);
    }


    @Override
    protected void onPostExecute(String result) {
        super.onPostExecute(result);


        progressDialog.dismiss();
        mTextViewResult.setText(result);
        Log.d(TAG, "response - " + result);

        if (result == null){

            mTextViewResult.setText(errorString);
        }
        else {

            mJsonString = result;
            showResult();
        }
    }


    @Override
    protected String doInBackground(String... params) {

        String serverURL = params[0];
        String postParameters = "yata_zone=" + params[1];


        try {

            URL url = new URL(serverURL);
            HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();


            httpURLConnection.setReadTimeout(5000);
            httpURLConnection.setConnectTimeout(5000);
            httpURLConnection.setRequestMethod("POST");
            httpURLConnection.setDoInput(true);
            httpURLConnection.connect();


            OutputStream outputStream = httpURLConnection.getOutputStream();
            outputStream.write(postParameters.getBytes("UTF-8"));
            outputStream.flush();
            outputStream.close();


            int responseStatusCode = httpURLConnection.getResponseCode();
            Log.d(TAG, "response code - " + responseStatusCode);

            InputStream inputStream;
            if(responseStatusCode == HttpURLConnection.HTTP_OK) {
                inputStream = httpURLConnection.getInputStream();
            }
            else{
                inputStream = httpURLConnection.getErrorStream();
            }


            InputStreamReader inputStreamReader = new InputStreamReader(inputStream, "UTF-8");
            BufferedReader bufferedReader = new BufferedReader(inputStreamReader);

            StringBuilder sb = new StringBuilder();
            String line;

            while((line = bufferedReader.readLine()) != null){
                sb.append(line);
            }

            bufferedReader.close();

            return sb.toString().trim();


        } catch (Exception e) {

            Log.d(TAG, "InsertData: Error ", e);
            errorString = e.toString();

            return null;
        }

    }
}


    private void showResult(){

        String TAG_JSON="jin10";
        String TAG_MC_seq = "MC_seq";
        String TAG_MCC_num = "MCC_num";
        String TAG_yata_zone ="yata_zone";
        try {
            JSONObject jsonObject = new JSONObject(mJsonString);
            JSONArray jsonArray = jsonObject.getJSONArray(TAG_JSON);

            for(int i=0;i<jsonArray.length();i++){

                JSONObject item = jsonArray.getJSONObject(i);

                String MC_seq = item.getString(TAG_MC_seq);
                String MCC_num = item.getString(TAG_MCC_num);
                String yata_zone = item.getString(TAG_yata_zone);
                HashMap<String,String> hashMap = new HashMap<>();

                hashMap.put(TAG_MC_seq, MC_seq);
                hashMap.put(TAG_MCC_num, MCC_num);
                hashMap.put(TAG_yata_zone, yata_zone);

                mArrayList.add(hashMap);
            }

            ListAdapter adapter = new SimpleAdapter(
                    popup.this, mArrayList, R.layout.item_list,
                    new String[]{TAG_MC_seq,TAG_MCC_num, TAG_yata_zone},
                    new int[]{R.id.textView_MC_seq, R.id.textView_MC_num, R.id.textView_yata_zone}
            );

            mListViewList.setAdapter(adapter);

        } catch (JSONException e) {

            Log.d(TAG, "showResult : ", e);
        }

    }


}
