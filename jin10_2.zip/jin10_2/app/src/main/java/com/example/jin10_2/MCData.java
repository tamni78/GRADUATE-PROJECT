package com.example.jin10_2;

public class MCData {
    private String MC_seq;
    private String MC_num;
    private String yata_zone;

    public String getMC_seq() {
        return MC_seq;
    }

    public void setMC_seq(String MC_seq) {
        this.MC_seq = MC_seq;
    }

    public String getMC_num() {
        return MC_num;
    }

    public void setMC_num(String MC_num) {
        this.MC_num = MC_num;
    }

    public String getYata_zone() {
        return yata_zone;
    }

    public void setYata_zone(String yata_zone) {
        this.yata_zone = yata_zone;
    }





}
