package com.example.jin10_2;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

public class smartkey extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_smartkey);
        ImageView img_lock = findViewById(R.id.img_lock);
        ImageView img_lock_open = findViewById(R.id.img_lock_open);

        img_lock.setOnClickListener(new Button.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(), "락버튼", Toast.LENGTH_SHORT).show();

            }
        }) ;

        img_lock_open.setOnClickListener(new Button.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(), "락해제버튼", Toast.LENGTH_SHORT).show();
            }
        }) ;


    }
}
