package com.example.jin10_2;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class MCAdapter extends RecyclerView.Adapter<MCAdapter.CustomViewHolder> {

    private ArrayList<MCData> mList = null;
    private Activity context = null;


    public MCAdapter(Activity context, ArrayList<MCData> list) {
        this.context = context;
        this.mList = list;
    }

    class CustomViewHolder extends RecyclerView.ViewHolder {
        protected TextView MC_seq;
        protected TextView MC_num;
        protected TextView yata_zone;


        public CustomViewHolder(View view) {
            super(view);
            this.MC_seq = (TextView) view.findViewById(R.id.textView_MC_seq);
            this.MC_num = (TextView) view.findViewById(R.id.textView_MC_num);
            this.yata_zone = (TextView) view.findViewById(R.id.textView_yata_zone);
        }
    }


    @Override
    public CustomViewHolder onCreateViewHolder(ViewGroup viewGroup, int viewType) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_list, null);
        CustomViewHolder viewHolder = new CustomViewHolder(view);

        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull CustomViewHolder viewholder, int position) {

        viewholder.MC_seq.setText(mList.get(position).getMC_seq());
        viewholder.MC_num.setText(mList.get(position).getMC_num());
        viewholder.yata_zone.setText(mList.get(position).getYata_zone());
    }

    @Override
    public int getItemCount() {
        return (null != mList ? mList.size() : 0);
    }
}
