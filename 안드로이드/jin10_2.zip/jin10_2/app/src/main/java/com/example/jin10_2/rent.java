package com.example.jin10_2;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.app.ProgressDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Calendar;
import java.util.GregorianCalendar;

public class rent extends AppCompatActivity {

    private static String IP_ADDRESS = "jin10.dothome.co.kr";
    private static String TAG = "phpexample";

    String  mcSeq,MC_num,yata_zone,userID;
    TextView textView;
    int year, month, day, hour, minute;
    TextView text_reservation_start_date,text_reservation_end_date,text_reservation_start_time,text_reservation_end_time;
    TextView text_rent_min,text_rent_fee;
    int start_min, end_min, rent_min,rent_fee_int;
    String startTime,endTime,rentSeq,rentFee;
    EditText edit_rent_seq;
    TextView text123,text456,text_rent;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rent);


        //오류검출용
        text_rent = findViewById(R.id.text_rent_result);
        text123 = findViewById(R.id.text123);
        text456 = findViewById(R.id.text456);
        GregorianCalendar calendar = new GregorianCalendar();
        year = calendar.get(Calendar.YEAR);
        month = calendar.get(Calendar.MONTH);
        day= calendar.get(Calendar.DAY_OF_MONTH);
        hour = calendar.get(Calendar.HOUR_OF_DAY);
        minute = calendar.get(Calendar.MINUTE);
        textView = findViewById(R.id.text_reserve);
        Button btnStart, btnEnd, btnrealEnd;

        Intent intent = getIntent();
        yata_zone = intent.getStringExtra("yata_zone");
        userID = intent.getStringExtra("userID");
        mcSeq = intent.getStringExtra("MC_seq");
        MC_num = intent.getStringExtra("MC_num");

        text_reservation_start_date = findViewById(R.id.text_reserve_start_date);
        text_reservation_end_date = findViewById(R.id.text_reserve_end_date);
        text_reservation_start_time = findViewById(R.id.text_reserve_start_time);
        text_reservation_end_time = findViewById(R.id.text_reserve_end_time);
        edit_rent_seq = findViewById(R.id.edit_rent_seq);
        text_rent_min =findViewById(R.id.text_rent_min);
        text_rent_fee=findViewById(R.id.text_rent_fee);
        btnrealEnd = findViewById(R.id.btnRealEnd);
        btnStart = findViewById(R.id.btn_reservation_1);
        btnEnd = (Button) findViewById(R.id.btn_reservation_2);

        textView.setText(userID+"님 반갑습니다. \n"+"선택하신 야타존 : "+yata_zone+"\n기기 순번 : "+mcSeq+"\n기기 번호 : "+MC_num+"");
        btnStart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new TimePickerDialog(rent.this, start_timeSetListener, hour, minute, false).show();
                new DatePickerDialog(rent.this, start_dateSetListener, year, month, day).show();
            }
        });
        btnEnd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new TimePickerDialog(rent.this, end_timeSetListener, hour, minute, false).show();
                new DatePickerDialog(rent.this, end_dateSetListener, year, month, day).show();
            }
        });

        btnrealEnd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(),"버튼 클릭",Toast.LENGTH_SHORT).show();
                rentSeq = edit_rent_seq.getText().toString();
                InsertData task = new InsertData();
                task.execute("http://" + IP_ADDRESS + "/Insert.php", rentSeq, startTime , endTime , rentFee, userID, mcSeq);
            }
        });

    }


    class InsertData extends AsyncTask<String, Void, String> {
        ProgressDialog progressDialog;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();

            progressDialog = ProgressDialog.show(rent.this,
                    "Please Wait", null, true, true);
        }


        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(result);

            progressDialog.dismiss();
            text_rent.setText(result);
            Log.d(TAG, "POST response  - " + result);
        }


        @Override
        protected String doInBackground(String... params) {

            String rentSeq = (String)params[1];
            String startTime = (String)params[2];
            String endTime = (String)params[3];
            String rentFee = (String)params[4];
            String userID = (String)params[5];
            String mcSeq = (String)params[6];

            String serverURL = (String)params[0];
            String postParameters = "rentSeq=" + rentSeq + "&startTime=" + startTime + "&endTime=" + endTime + "&rentFee=" + rentFee + "&userID=" + userID+"&mcSeq=" + mcSeq;


            try {

                URL url = new URL(serverURL);
                HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();


                httpURLConnection.setReadTimeout(5000);
                httpURLConnection.setConnectTimeout(5000);
                httpURLConnection.setRequestMethod("POST");
                httpURLConnection.connect();


                OutputStream outputStream = httpURLConnection.getOutputStream();
                outputStream.write(postParameters.getBytes("UTF-8"));
                outputStream.flush();
                outputStream.close();


                int responseStatusCode = httpURLConnection.getResponseCode();
                Log.d(TAG, "POST response code - " + responseStatusCode);

                InputStream inputStream;
                if(responseStatusCode == HttpURLConnection.HTTP_OK) {
                    inputStream = httpURLConnection.getInputStream();
                }
                else{
                    inputStream = httpURLConnection.getErrorStream();
                }


                InputStreamReader inputStreamReader = new InputStreamReader(inputStream, "UTF-8");
                BufferedReader bufferedReader = new BufferedReader(inputStreamReader);

                StringBuilder sb = new StringBuilder();
                String line = null;

                while((line = bufferedReader.readLine()) != null){
                    sb.append(line);
                }


                bufferedReader.close();


                return sb.toString();


            } catch (Exception e) {

                Log.d(TAG, "InsertData: Error ", e);

                return new String("Error: " + e.getMessage());
            }

        }
    }
    private TimePickerDialog.OnTimeSetListener start_timeSetListener = new TimePickerDialog.OnTimeSetListener() {
        @Override
        public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
            // TODO Auto-generated method stub
            String msg = String.format("%d / %d / %d", year, hourOfDay, minute);
            Toast.makeText(rent.this, msg, Toast.LENGTH_SHORT).show();
            text_reservation_start_time.setText(hourOfDay+"시 "+ minute+"분");
            start_min = start_min+hourOfDay*60+minute;
            startTime =  ""+startTime+""+hourOfDay+":"+minute+":00";
            text123.setText(startTime);
        }

    };
    private DatePickerDialog.OnDateSetListener start_dateSetListener = new DatePickerDialog.OnDateSetListener() {
                @Override
                public void onDateSet(DatePicker view, int year, int monthOfYear,
                                      int dayOfMonth) {
                    // TODO Auto-generated method stub
                    monthOfYear=monthOfYear+1;
                    String msg = String.format("%d / %d / %d", year,monthOfYear, dayOfMonth);
                    Toast.makeText(rent.this, msg, Toast.LENGTH_SHORT).show();
                    text_reservation_start_date.setText(""+ year+"년 "+monthOfYear+"월 "+ dayOfMonth+"일");
                    startTime =  ""+year+"-"+monthOfYear+"-"+dayOfMonth+" ";

        }

    };
    private TimePickerDialog.OnTimeSetListener end_timeSetListener = new TimePickerDialog.OnTimeSetListener() {
        @Override
        public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
            // TODO Auto-generated method stub
            String msg = String.format("%d / %d / %d", year, hourOfDay, minute);
            Toast.makeText(rent.this, msg, Toast.LENGTH_SHORT).show();
            text_reservation_end_time.setText(hourOfDay+"시 "+ minute+"분");
            end_min = end_min+hourOfDay*60+minute;
            rent_min=end_min-start_min;
            text_rent_min.setText(rent_min+"분");
            rent_fee_int = rent_min*1000;

            text_rent_fee.setText(rent_fee_int+"원");
            endTime =""+endTime+""+hourOfDay+":"+minute+":00";
            rentFee = Integer.toString(rent_fee_int);
            text456.setText(endTime);
        }

    };
    private DatePickerDialog.OnDateSetListener end_dateSetListener = new DatePickerDialog.OnDateSetListener() {
        @Override
        public void onDateSet(DatePicker view, int year, int monthOfYear,
                              int dayOfMonth) {
                    // TODO Auto-generated method stub
            monthOfYear=monthOfYear+1;
            String msg = String.format("%d / %d / %d", year,monthOfYear, dayOfMonth);
            Toast.makeText(rent.this, msg, Toast.LENGTH_SHORT).show();
            text_reservation_end_date.setText(""+ year+"년 "+monthOfYear+"월 "+ dayOfMonth+"일");
            endTime =  ""+year+"-"+monthOfYear+"-"+dayOfMonth+" ";

        }

    };

}
