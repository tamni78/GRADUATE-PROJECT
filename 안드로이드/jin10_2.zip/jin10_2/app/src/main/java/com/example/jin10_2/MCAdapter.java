package com.example.jin10_2;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.ArrayList;

public class MCAdapter extends BaseAdapter{

    private ArrayList<MCData> mList = new ArrayList<MCData>();


    public MCAdapter() {

    }

    @Override
    public int getCount() {
        return mList.size() ;
    }

    @Override
    public Object getItem(int position) {
        return mList.get(position) ;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        final int pos = position;
        final Context context = parent.getContext();

        // "listview_item" Layout을 inflate하여 convertView 참조 획득.
        if (convertView == null) {
            LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = inflater.inflate(R.layout.item_list, parent, false);
        }

        // 화면에 표시될 View(Layout이 inflate된)으로부터 위젯에 대한 참조 획득
        TextView MC_seq_view = (TextView) convertView.findViewById(R.id.textView_MC_seq) ;
        TextView MC_num_view = (TextView) convertView.findViewById(R.id.textView_MC_num) ;
        TextView yata_zone_view = (TextView) convertView.findViewById(R.id.textView_yata_zone) ;

        // Data Set(listViewItemList)에서 position에 위치한 데이터 참조 획득
        MCData listViewItem = mList.get(position);

        // 아이템 내 각 위젯에 데이터 반영
        MC_seq_view.setText(listViewItem.getMC_seq());
        MC_num_view.setText(listViewItem.getMC_num());
        yata_zone_view.setText(listViewItem.getYata_zone());

        return convertView;
    }

    public void addItem(String MC_seq, String MC_num, String yata_zone) {
        MCData item = new MCData();

        item.setMC_seq(MC_seq);
        item.setMC_num(MC_num);
        item.setYata_zone(yata_zone);

        mList.add(item);
    }

}
