package com.example.jin10_2;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;

public class popup extends AppCompatActivity {
    private String zone;
    private String userID;
    private TextView textView1,textView2,mTextViewResult;

    private static String IP_ADDRESS = "jin10.dothome.co.kr";
    private static String TAG = "phpexample";

    ArrayList<HashMap<String, String>> mArrayList;
    private ArrayList<MCData> mcDataArrayList;
    ListView mListViewList;
    private String mJsonString;
    MCAdapter adapter;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_popup);

        //인텐트로 아이디와 야타존 받아오는 부분
        Intent intent = getIntent();
        zone = intent.getStringExtra("zone");
        userID = intent.getStringExtra("userID");

        mListViewList = (ListView) findViewById(R.id.listView_main_list);
        textView1 = findViewById(R.id.text_popup1);
        textView2 = findViewById(R.id.text_popup2);
        mTextViewResult = findViewById(R.id.mTextViewResult);


        textView1.setText(userID + "님 반갑습니다");
        textView2.setText(zone + "의 오토바이 목록입니다.");


        String Keyword = zone;

        GetData task = new GetData();
        task.execute("http://" + IP_ADDRESS + "/query.php", Keyword);

        mArrayList = new ArrayList<>();

    }



private class GetData extends AsyncTask<String, Void, String>{

    ProgressDialog progressDialog;
    String errorString = null;

    @Override
    protected void onPreExecute() {
        super.onPreExecute();

        progressDialog = ProgressDialog.show(popup.this,
                "Please Wait", null, true, true);
    }


    @Override
    protected void onPostExecute(String result) {
        super.onPostExecute(result);


        progressDialog.dismiss();
        mTextViewResult.setText(result);
        Log.d(TAG, "response - " + result);

        if (result == null){

            mTextViewResult.setText(errorString);
        }
        else {

            mJsonString = result;
            showResult();
        }
    }


    @Override
    protected String doInBackground(String... params) {

        String serverURL = params[0];
        String postParameters = "yata_zone=" + params[1];


        try {

            URL url = new URL(serverURL);
            HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();


            httpURLConnection.setReadTimeout(5000);
            httpURLConnection.setConnectTimeout(5000);
            httpURLConnection.setRequestMethod("POST");
            httpURLConnection.setDoInput(true);
            httpURLConnection.connect();


            OutputStream outputStream = httpURLConnection.getOutputStream();
            outputStream.write(postParameters.getBytes("UTF-8"));
            outputStream.flush();
            outputStream.close();


            int responseStatusCode = httpURLConnection.getResponseCode();
            Log.d(TAG, "response code - " + responseStatusCode);

            InputStream inputStream;
            if(responseStatusCode == HttpURLConnection.HTTP_OK) {
                inputStream = httpURLConnection.getInputStream();
            }
            else{
                inputStream = httpURLConnection.getErrorStream();
            }


            InputStreamReader inputStreamReader = new InputStreamReader(inputStream, "UTF-8");
            BufferedReader bufferedReader = new BufferedReader(inputStreamReader);

            StringBuilder sb = new StringBuilder();
            String line;

            while((line = bufferedReader.readLine()) != null){
                sb.append(line);
            }

            bufferedReader.close();

            return sb.toString().trim();


        } catch (Exception e) {

            Log.d(TAG, "InsertData: Error ", e);
            errorString = e.toString();

            return null;
        }

    }
}


    private void showResult(){

        adapter = new MCAdapter() ;
        String TAG_JSON="jin10";
        String TAG_MC_seq = "mcSeq";
        String TAG_MC_num = "mcNum";
        String TAG_yata_zone ="yata_zone";
        try {
            JSONObject jsonObject = new JSONObject(mJsonString);
            JSONArray jsonArray = jsonObject.getJSONArray(TAG_JSON);

            for(int i=0;i<jsonArray.length();i++){

                JSONObject item = jsonArray.getJSONObject(i);

                String MC_seq = item.getString(TAG_MC_seq);
                String MC_num = item.getString(TAG_MC_num);
                String yata_zone = item.getString(TAG_yata_zone);
                MCData mcData = new MCData();

                mcData.setMC_seq(MC_seq);
                mcData.setMC_num(MC_num);
                mcData.setYata_zone(yata_zone);

                adapter.addItem(MC_seq, MC_num, yata_zone) ;
            }

            mListViewList.setAdapter(adapter);
            mListViewList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                    MCData item = (MCData) parent.getItemAtPosition(position) ;

                    String MC_seq = item.getMC_seq() ;
                    String MC_num = item.getMC_num() ;
                    String yata_zone = item.getYata_zone() ;
                    Intent intent = new Intent(getApplicationContext(), rent.class);
                    intent.putExtra("MC_seq",MC_seq);
                    intent.putExtra("MC_num",MC_num);
                    intent.putExtra("yata_zone",yata_zone);
                    intent.putExtra("userID",userID);
                    startActivity(intent);
                }

            });

        } catch (JSONException e) {

            Log.d(TAG, "showResult : ", e);
        }

    }


}
